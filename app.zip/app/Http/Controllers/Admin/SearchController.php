<?php

namespace App\Http\Controllers\Admin;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Admin\SearchController;

class SearchController extends Controller
{
    public function searchcat(Request $request)
    {
        $q = $request->input('q');
        $category = Category::where( 'name', 'LIKE', '%' . $q . '%' )
        ->orWhere ( 'slug', 'LIKE', '%' . $q . '%' )
        ->orWhere ( 'id', 'LIKE', '%' . $q . '%' )
        ->orderBy('created_at','desc')
        ->paginate (3);
        $category -> appends(['search' => $q]);
        $count = Category::orderBy('created_at','desc')->count();
        return view('admin.category.index', compact('category','count'));
    }

    public function searchprod(Request $request)
    {
        $q = $request->input('q');
        $products = Product::where( 'name', 'LIKE', '%' . $q . '%' )
        ->orWhere ( 'slug', 'LIKE', '%' . $q . '%' )
        ->orWhere ( 'id', 'LIKE', '%' . $q . '%' )
        ->orWhere ( 'cate_id', 'LIKE', '%' . $q . '%' )
        ->orderBy('cate_id','desc')
        ->paginate (4);
        $products -> appends(['search' => $q]);
        $count = Product::orderBy('created_at','desc')->count();
        return view('admin.product.index', compact('products','count'));
    }
}
