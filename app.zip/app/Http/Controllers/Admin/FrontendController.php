<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;
use App\Models\Order;
use App\Models\Sales;
use App\Models\Product;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class FrontendController extends Controller
{
    public function index()
    {
        $dt = new Carbon('now', 'AWST');
        $dt2 = Carbon::createFromDate(1987, 4, 23);
        $yesterday = $dt->copy()->subDay();
        $lastweek = $dt->copy()->subWeek();
        $lastmonth = $dt->copy()->subMonth();
        $sales = Sales::all();
        $orderitems = OrderItem::all();
        $orders = Sales::where('created_at','>' ,$yesterday)->get();
        $ordersbyweek = Sales::where('created_at','>' ,$lastweek)->get();
        $ordersbymonth = Sales::where('created_at','>' ,$lastmonth)->get();
        $products = Product::where('qty', '<', 6)->orderBy('qty','asc')->simplePaginate(5);
        $productscount = Product::where('qty', '<', 6)->orderBy('qty','asc')->count();
        $top_sales = DB::table('products')
        ->LeftJoin('sales','products.id', '=', 'sales.prod_id')
        ->selectRaw('products.id, SUM(sales.qty) as total')
        ->groupBy('products.id')
        ->orderBy('total','desc')
        ->get();
        $topProducts = [];
        foreach ($top_sales as $s){
            if($s->total != NULL){
                $p = Product::findOrFail($s->id);
                $p->totalQty = $s->total;
                $topProducts[]= $p;
            }

        }
        return view('admin.index', compact('orders','products','ordersbyweek','ordersbymonth','sales','orderitems','topProducts','productscount'));
    }
}
