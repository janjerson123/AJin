<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;
use App\Models\Order;
use App\Models\Sales;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::where('status' , '<=' ,'2')->get();
        return view('admin.orders.index', compact('orders'));
    }

    public function view($id)
    {
        $orders = Order::where('id' , $id)->first();
        return view('admin.orders.view', compact('orders'));
    }

    public function updateorder(Request $request, $id)
    {
        $orders = Order::find($id);
        $orders->status = $request -> input('order_status');
        $orders->update();
        if($orders->status == 3)
        {
            $total = 0;
                if(Sales::where('order_id',$orders->id)->exists())
                {
                    return redirect('orders')->with('status','Order Updated.');
                }
                else
                {
                    $solditems = OrderItem::where('order_id', $orders->id)->get();
                    foreach($solditems as $item)
                    {
                        Sales::create([
                            'order_id'=> $orders->id,
                            'user_id'=> $orders->user_id,
                            'prod_id'=> $item->prod_id,
                            'qty'=> $item->qty,
                            'total_price'=> $item->products->selling_price * $item->qty,
                        ]);
                    }
                }
        }
        else
        {
            $salesitem = Sales::where('order_id', $orders->id )->where('user_id',$orders->user_id)->get();
            foreach($salesitem as $item)
            {
                $item->delete();
            }
            return redirect('orders')->with('status','Order Updated.');
        }
        return redirect('orders')->with('status','Order Updated.');
    }

    public function orderdelivered()
    {
        $orders = Order::where('status' , '3')->get();
        return view('admin.orders.delivered', compact('orders'));
    }

    public function ordercancelled()
    {
        $orders = Order::where('status' , '4')->get();
        return view('admin.orders.cancelled', compact('orders'));
    }
}
