<?php

namespace App\Http\Controllers\Admin;

use App\Models\Feedback;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class FeedbackController extends Controller
{
    public function index()
    {
        $reviews = Feedback::all();
        $count = Feedback::where('status','0')->count();
        return view('admin.feedback.index', compact('reviews','count'));
    }
    public function changeStatus(Request $request)

    {

        $feedback = Feedback::find($request->feedback_id);

        $feedback->status = $request->status;

        $feedback->save();



        return response()->json(['success'=>'Status change successfully.']);

    }


}