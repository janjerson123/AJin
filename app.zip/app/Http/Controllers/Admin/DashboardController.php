<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DashboardController extends Controller
{
    public function users()
    {
        $users = User::all();
        return view('admin.users.index', compact('users'));
    }

    public function viewusers($id)
    {
        $users = User::find($id);
        return view('admin.users.view', compact('users'));
    }

    public function updateadminusers(Request $request, $id)
    {
        $users = User::find($id);
        $users-> role_as = $request->input('role_as');
        $users-> name = $request->input('fname');
        $users-> lname = $request->input('lname');
        $users-> phone = $request->input('phone');
        $users-> address1 = $request->input('address1');
        $users-> address2 = $request->input('address2');
        $users-> city = $request->input('city');
        $users-> zipcode = $request->input('zipcode');
        $users->update();
        return redirect('users')->with('status','User Details Updated.');
    }



}
