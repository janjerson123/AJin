<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    public function profiles(){
        $user = User::where('id', Auth::id())->get();
        return view('frontend.profile', compact('user'));
    }

    public function updtProfileInfo(Request $request){

        $User = User::find(Auth::id());
        $User-> name = $request->input('fname');
        $User-> lname = $request->input('lname');
        $User->update();
        return redirect('profile')->with('status','Profile Information Updated.');
    }

    public function updtProfileCInfo(Request $request){

        $User = User::find(Auth::id());
        $User-> phone = $request->input('phone');
        $User-> address1 = $request->input('address1');
        $User-> address2 = $request->input('address2');
        $User-> city = $request->input('city');
        $User-> zipcode = $request->input('zipcode');
        $User->update();
        return redirect('profile')->with('status','Profile Contact Information Updated.');
    }

    public function updtProfilePass(Request $request){

        $request->validate([
            'old_password' => 'required',
            'new_password' => 'required|confirmed|min:8',
        ]);
        if(!Hash::check($request->old_password, auth()->user()->password)){
            return redirect('profile#changepassword')->with('status',"Old Password Does not match.");
        }
        User::whereId(auth()->user()->id)->update([
            'password' => Hash::make($request->new_password)
        ]);
        return back()->with('status',"Your Password has been Updated.");
    }
}
